#!/usr/bin/env bash
# Sets up the Android SDK in /home/runner/android-sdk/
# Run this once after a fresh Replit restart before building.

set -e

ANDROID_SDK_DIR=/home/runner/android-sdk
CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"

if [ -f "$ANDROID_SDK_DIR/cmdline-tools/latest/bin/sdkmanager" ]; then
  echo "Android SDK already present at $ANDROID_SDK_DIR — skipping download."
else
  echo "Downloading Android command-line tools..."
  mkdir -p "$ANDROID_SDK_DIR/cmdline-tools"
  curl -L -o /tmp/cmdline-tools.zip "$CMDLINE_TOOLS_URL"
  unzip -q /tmp/cmdline-tools.zip -d "$ANDROID_SDK_DIR/cmdline-tools/"
  mv "$ANDROID_SDK_DIR/cmdline-tools/cmdline-tools" "$ANDROID_SDK_DIR/cmdline-tools/latest"
  rm /tmp/cmdline-tools.zip
  echo "Command-line tools installed."
fi

export ANDROID_HOME=$ANDROID_SDK_DIR
export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH

echo "Accepting licenses and installing SDK components..."
yes | sdkmanager --licenses > /dev/null 2>&1
sdkmanager --install "platform-tools" "platforms;android-34" "build-tools;34.0.0"

echo ""
echo "Android SDK ready at $ANDROID_SDK_DIR"
echo "Installed packages:"
sdkmanager --list_installed
